#include "MirfSpiDriver.h"

uint8_t MirfSpiDriver::transfer(uint8_t data){
	return 0;
}

void MirfSpiDriver::begin(){
}

void MirfSpiDriver::end(){
}
