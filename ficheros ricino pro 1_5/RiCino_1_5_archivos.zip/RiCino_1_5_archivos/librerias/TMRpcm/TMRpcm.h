/*Library by TMRh20
  Released into the public domain.*/
#include <Arduino.h>

#define SAMPLE_RATE 16000


#ifndef tmrPCM_h
#define tmrPCM_h


class TMRpcm
{
 public:
	TMRpcm();
	void play(char* filename);
	int speakerPin;
	void stopPlayback();
	void volume(int vol);
	void disable();

 private:
 	void startPlayback();


};

extern void stopPlay();

#endif