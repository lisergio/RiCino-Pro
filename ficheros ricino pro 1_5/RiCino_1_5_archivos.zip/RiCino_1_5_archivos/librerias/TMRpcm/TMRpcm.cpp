/*Library by TMRh20 2012
  Released into the public domain.*/

#include <SD.h>
#include <Arduino.h>
#include <TMRpcm.h>




const int buffSize = 100; //note: there are 2 sound buffers. This will require (soundBuff*2) memory free

volatile byte buffer[2][buffSize+1];
volatile boolean buffEmpty[2] = {false,false};
volatile boolean whichBuff = false;
volatile int buffCount = 0;

int volMod = 3;

File sFile;


TMRpcm::TMRpcm(){
	speakerPin = 11;
}


void TMRpcm::play(char* filename){
	pinMode(speakerPin, OUTPUT);
  stopPlayback();
  Serial.print("Playing: ");Serial.println(filename);

  sFile = SD.open(filename);

  if(sFile){
    // clear out the WAV header information
    for(int i=0; i< 44; i++){
      if(sFile.available() ){ sFile.read(); }
    }

    for(int i=0; i<buffSize; i++){   //load up a single buffer, then start playback
      buffer[0][i] = sFile.read();
    }
    whichBuff = false; buffEmpty[0] = false; buffEmpty[1] = true;

    startPlayback();
  }else{Serial.println("failed to open music file"); }
}



void TMRpcm::volume(int upDown){
	volMod = volMod + upDown;
	volMod = constrain(volMod,1,3);
}


ISR(TIMER1_COMPB_vect){

  // The first step is to disable this interrupt before manually enabling global interrupts.
  // This allows this interrupt vector (COMPB) to continue loading data while allowing the overflow interrupt
  // to interrupt it. ( Nested Interrupts )

  TIMSK1 &= ~(_BV(OCIE1B));

 //Now enable global interupts before this interrupt is finished, so the music can interrupt the buffering
  sei();

  if(sFile.available() < buffSize){stopPlay();}

  if(buffEmpty[0]){
    for(int i=0; i<buffSize; i++){ buffer[0][i] = sFile.read(); }
    buffEmpty[0] = 0;
  }else
  if(buffEmpty[1]){
    for(int i=0; i<buffSize; i++){ buffer[1][i] = sFile.read();  }
    buffEmpty[1] = 0;
  }

  //re-enable this interrupt vector
  TIMSK1 = ( _BV(OCIE1B) | _BV(TOIE1) );
}


ISR(TIMER1_OVF_vect){

   OCR1A = buffer[!whichBuff][buffCount] * volMod;
   buffCount++;
   if(buffCount == buffSize){ buffCount = 0; whichBuff = !whichBuff; buffEmpty[whichBuff] = true; }

}


void TMRpcm::startPlayback(){

  TCCR1A = 0;
  TCCR1B = _BV(WGM13);
  long cycles = (F_CPU * (1000000/SAMPLE_RATE)) / 2000000;
  ICR1 = cycles;
  TCCR1B |= _BV(CS10);
  DDRE |= _BV(PORTE1);
  TCCR1A |= _BV(COM1A1);
  TIMSK1 = ( _BV(OCIE1B) | _BV(TOIE1) );
}

void TMRpcm::stopPlayback(){
  if(sFile){sFile.close();}
  TIMSK1 &= ~( _BV(OCIE1B) | _BV(TOIE1) );
}

void stopPlay(){

	if(sFile){sFile.close();}
	  TIMSK1 &= ~( _BV(OCIE1B) | _BV(TOIE1) );
}

void TMRpcm::disable(){

  if(sFile){sFile.close();}
  TIMSK1 &= ~( _BV(OCIE1B) | _BV(TOIE1) );
  TCCR1B &= ~(_BV(CS10) | _BV(CS11) | _BV(CS12));

}

